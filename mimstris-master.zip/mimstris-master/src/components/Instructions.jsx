import React from 'react'

export default props => (
  <p className='instructions'>
    WASD or Arrow keys to move - Shift, / or up to Rotate - Enter to pause or restart - Z to undo. Also supports gamepads in some browsers.
  </p>
)
